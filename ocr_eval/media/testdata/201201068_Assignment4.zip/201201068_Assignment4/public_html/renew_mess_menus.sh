rm OBH-FF.pdf
rm OBH-GF.pdf
rm yuktahar.pdf
rm NBH.pdf
rm ff.hmtl
rm gf.html
rm yukta.html
rm nbh.html
wget https://mess.iiit.ac.in/mess/web/uploads/OBH-FF.pdf --no-check-certificate
wget https://mess.iiit.ac.in/mess/web/uploads/OBH-GF.pdf --no-check-certificate
wget https://mess.iiit.ac.in/mess/web/uploads/yuktahar.pdf --no-check-certificate
wget https://mess.iiit.ac.in/mess/web/uploads/NBH.pdf --no-check-certificate
pdftotext OBH-FF.pdf ff.txt
pdftotext OBH-GF.pdf gf.txt
pdftotext yuktahar.pdf yukta.txt
pdftotext NBH.pdf nbh.txt
rm OBH-FF.pdf
rm OBH-GF.pdf
rm yuktahar.pdf
rm NBH.pdf

